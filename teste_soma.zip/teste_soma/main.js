const soma = require('./soma')
console.log("Soma 5+5 = ", soma(5,5));